package com.cg.ibs.rm.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.ServiceProvider;
import com.cg.ibs.rm.dao.AutoPaymentDAO;
import com.cg.ibs.rm.dao.AutoPaymentDAOImpl;
import com.cg.ibs.rm.exception.IBSExceptions;

public class AutoPaymentServiceImpl implements AutoPaymentService {
	private static Logger logger = Logger.getLogger(AutoPaymentServiceImpl.class);


	private AutoPaymentDAO autoPaymentDao = new AutoPaymentDAOImpl();

	@Override
	public Set<AutoPayment> showAutopaymentDetails(String uci) throws IBSExceptions {
		logger.info("entering into showAutopaymentDetails method of AutoPaymentServiceImpl class");
		return autoPaymentDao.getAutopaymentDetails(uci);

	}

	@Override
	public Set<ServiceProvider> showIBSServiceProviders() throws IBSExceptions {
		logger.info("entering into showIBSServiceProviders method of AutoPaymentServiceImpl class");
		return autoPaymentDao.showServiceProviderList();

	}

	@Override
	public boolean autoDeduction(String uci, AutoPayment autoPayment) throws IBSExceptions {
		logger.info("entering into autoDeduction method of AutoPaymentServiceImpl class");
		LocalDate today = LocalDate.now();
		boolean validAutoDeduct = false;
		if (Pattern.matches("^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$", autoPayment.getDateOfStart())) {
			DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate startOfAutoPayment = LocalDate.parse(autoPayment.getDateOfStart(), dtFormatter);
			logger.debug(autoPaymentDao.getCurrentBalance(uci));
			if (!startOfAutoPayment.isBefore(today)) {
				validAutoDeduct = autoPaymentDao.copyDetails(uci, autoPayment);
				while (today.equals(startOfAutoPayment) && 0 <= autoPaymentDao.getCurrentBalance(uci).compareTo(autoPayment.getAmount())) {
						BigDecimal balance = autoPaymentDao.getCurrentBalance(uci).subtract(autoPayment.getAmount());
						autoPaymentDao.setCurrentBalance(uci, balance);
						startOfAutoPayment = startOfAutoPayment.plusMonths(1);
						logger.debug(autoPaymentDao.getCurrentBalance(uci));
				}

			}
		}
		return validAutoDeduct;
	}

	@Override
	public boolean updateRequirements(String uci, BigInteger spi) throws IBSExceptions {
		//logger.info("entering into updateRequirements method of AutoPaymentServiceImpl class");
		return autoPaymentDao.deleteDetails(uci, spi);
	}

}
