package com.cg.ibs.rm.service;

import java.math.BigInteger;
import java.util.Set;

import org.apache.log4j.Logger;
import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.dao.Bank_AdminDAO;
import com.cg.ibs.rm.dao.Bank_AdminDAOImpl;
import com.cg.ibs.rm.exception.IBSExceptions;

public class Bank_AdminServiceImpl implements Bank_AdminService {
	private Bank_AdminDAO bankRepresentativeDAO = new Bank_AdminDAOImpl();
	private static Logger logger = Logger.getLogger(Bank_AdminServiceImpl.class);


	@Override
	public Set<String> showRequests() throws IBSExceptions {
		logger.info("entering into showRequests method of BankRepresentativeServiceImpl class");
		return bankRepresentativeDAO.getRequests();
		
	}

	@Override
	public Set<CreditCard> showUnapprovedCreditCards(String uci) throws IBSExceptions {
		logger.info("entering into showUnapprovedCreditCards method of BankRepresentativeServiceImpl class");
		return bankRepresentativeDAO.getCreditCardDetails(uci);

	}

	@Override
	public Set<Beneficiary> showUnapprovedBeneficiaries(String uci) throws IBSExceptions {
		logger.info("entering into showUnapprovedBeneficiaries method of BankRepresentativeServiceImpl class");
		return bankRepresentativeDAO.getBeneficiaryDetails(uci);
	}

	@Override
	public boolean saveCreditCardDetails(String uci, CreditCard card) throws IBSExceptions {
		logger.info("entering into saveCreditCardDetails method of BankRepresentativeServiceImpl class");
		return bankRepresentativeDAO.copyCreditCardDetails(uci, card);
	}

	@Override
	public void saveBeneficiaryDetails(String uci, Beneficiary beneficiary) throws IBSExceptions {
		logger.info("entering into saveBeneficiaryDetails method of BankRepresentativeServiceImpl class");
		bankRepresentativeDAO.copyBeneficiaryDetails(uci, beneficiary);
	}

	@Override
	public boolean checkUciList(String uci) throws IBSExceptions {
		logger.info("entering into checkUciList method of BankRepresentativeServiceImpl class");
		boolean checkUci=false;
		if(bankRepresentativeDAO.getUCIList().contains(uci)) {
			checkUci=true;
		}
		return checkUci;
	}
	public boolean deleteBenficiary(BigInteger accountNumber) throws IBSExceptions {
		logger.info("entering into deleteBenficiary method of BankRepresentativeServiceImpl class");
		boolean checkDelete=false;
		if(bankRepresentativeDAO.deleteBeneficiaryDetails(accountNumber))
			checkDelete=true;
		return checkDelete;
	}

	@Override
	public boolean deleteCreditCard(BigInteger creditCardNumber) throws IBSExceptions {
		logger.info("entering into deleteCreditCard method of BankRepresentativeServiceImpl class");
		boolean checkDelete=false;
		if(bankRepresentativeDAO.deleteCreditCardDetails(creditCardNumber))
			checkDelete=true;
		return checkDelete;
	}
}
