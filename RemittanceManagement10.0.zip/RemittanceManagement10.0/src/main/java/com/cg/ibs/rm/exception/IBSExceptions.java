package com.cg.ibs.rm.exception;

public class IBSExceptions extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9171631393605992087L;

	public IBSExceptions(String message)
	{
		super(message);
	}
}
