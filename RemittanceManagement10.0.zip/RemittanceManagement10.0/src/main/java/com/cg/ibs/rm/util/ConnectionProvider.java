package com.cg.ibs.rm.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.cg.ibs.rm.exception.ExceptionMessages;
import com.cg.ibs.rm.exception.IBSExceptions;

public class ConnectionProvider {
	private ConnectionProvider() {
		super();
	}
	public static Connection getConnection() throws IBSExceptions {
		Connection connection = null;
		if (null == connection) {
			ResourceBundle bundle = ResourceBundle.getBundle("ibs");
			String url = bundle.getString("url");
			String user = bundle.getString("user");
			String password = bundle.getString("password");

			try {
				connection = DriverManager.getConnection(url, user, password);
			} catch (SQLException exception) {
				throw new IBSExceptions(ExceptionMessages.ERROR11);
			}
		}
		return connection;
	}
}
